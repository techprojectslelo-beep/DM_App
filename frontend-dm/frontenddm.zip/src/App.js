import React from 'react';
import Dashboard from './pages/Dashboard';

function App() {
  return (
    <div className="App">
      {/* For now, we render Dashboard directly. 
          Later, you can wrap this in a Router for multiple pages. */}
      <Dashboard />
    </div>
  );
}

export default App;