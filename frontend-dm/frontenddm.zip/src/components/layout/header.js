import React from 'react';
import { 
  LayoutDashboard, 
  Briefcase, 
  Users, 
  Bell,
  PlusCircle,
  Menu
} from 'lucide-react';

const HeaderLink = ({ label, icon, active = false, onClick }) => (
  <div 
    onClick={onClick}
    className={`flex items-center gap-2 cursor-pointer transition-all relative py-7 px-1 ${
      active ? 'text-indigo-600' : 'text-slate-400 hover:text-slate-600'
    }`}
  >
    {icon}
    <span className="text-[11px] font-black uppercase tracking-[0.15em] hidden sm:inline">{label}</span>
    {active && (
      <div className="absolute bottom-0 left-0 w-full h-1 bg-indigo-600 rounded-t-full shadow-[0_-4px_12px_rgba(79,70,229,0.4)]"></div>
    )}
  </div>
);

const Header = ({ activePage = 'dashboard', setActivePage, setIsSidebarOpen }) => {
  return (
    <header className="h-20 bg-white flex items-center justify-between lg:justify-end px-6 md:px-12 relative z-[140] shrink-0 border-b border-slate-100 lg:border-none">
      
      {/* MOBILE MENU TOGGLE - Left Side */}
      <button 
        onClick={() => setIsSidebarOpen(true)}
        className="lg:hidden p-2 text-slate-600 bg-slate-50 rounded-xl border border-slate-200"
      >
        <Menu size={20} />
      </button>

      {/* MOBILE REFINED CONCAVE LOOK */}
      <style>{`
        @media (max-width: 1024px) {
          header {
            border-bottom-left-radius: 24px;
            border-bottom-right-radius: 0px;
          }
          /* Right side inverted curve - matching the 24px radius */
          header::after {
            content: '';
            position: absolute;
            bottom: -24px;
            right: 0;
            height: 24px;
            width: 24px;
            background-color: transparent;
            border-top-right-radius: 24px;
            box-shadow: 10px -10px 0 0 #fff;
            pointer-events: none;
          }
        }
      `}</style>

      <div className="flex items-center gap-6 md:gap-10">
        {/* NAVIGATION */}
        <nav className="flex items-center gap-4 md:gap-10 h-full">
          <HeaderLink 
            label="Dashboard" 
            active={activePage === 'dashboard'} 
            icon={<LayoutDashboard size={18}/>} 
            onClick={() => setActivePage('dashboard')}
          />
          <HeaderLink 
            label="Brands" 
            active={activePage === 'brands'} 
            icon={<Briefcase size={18}/>} 
            onClick={() => setActivePage('brands')}
          />
          <HeaderLink 
            label="Team" 
            active={activePage === 'users'} 
            icon={<Users size={18}/>} 
            onClick={() => setActivePage('users')}
          />
        </nav>

        {/* SEARCH & PROFILE GROUP */}
        <div className="flex items-center gap-3 md:gap-6 pl-4 border-l border-slate-100">
          <button className="hidden xl:flex items-center gap-2 bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl hover:bg-indigo-100 transition-all group border border-indigo-100">
              <PlusCircle size={16} className="group-hover:rotate-90 transition-transform duration-300"/>
              <span className="text-[10px] font-black uppercase tracking-widest">Quick Post</span>
          </button>
          
          <div className="relative cursor-pointer p-2 hover:bg-slate-50 rounded-xl transition-all hidden sm:block">
            <Bell size={20} className="text-slate-400" />
            <div className="absolute top-2 right-2.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right hidden sm:block">
              <div className="text-[10px] font-black text-slate-900 uppercase leading-tight">Admin</div>
              <div className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Stack Lead</div>
            </div>
            <div className="w-10 h-10 bg-slate-900 rounded-2xl flex items-center justify-center text-white text-xs font-black shadow-lg shadow-slate-200">
              AD
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;