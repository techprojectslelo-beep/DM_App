import React, { useState } from 'react';
import { 
  ChevronDown, Search, ChevronUp, ChevronLeft, ChevronRight,
  Layout, Image, Mic, Mail, Video, X, Filter
} from 'lucide-react';
import LogoWhite from '../../assets/TechC-white.svg'; 

const Sidebar = ({ isOpen, setIsOpen }) => {
  const [searchQuery, setSearchQuery] = useState("");
  const [isBrandOpen, setIsBrandOpen] = useState(true);
  const [isTypeOpen, setIsTypeOpen] = useState(true);

  const brands = ["Apple", "Google", "MOTOROLA", "vivo", "OPPO", "Infinix", "Samsung", "Xiaomi", "Realme", "Nokia"];
  
  const postTypes = [
    { label: "Canva Post", icon: <Image size={12} /> },
    { label: "Reel", icon: <Video size={12} /> },
    { label: "Image", icon: <Image size={12} /> },
    { label: "Engagement", icon: <Mic size={12} /> },
    { label: "Mail", icon: <Mail size={12} /> },
    { label: "Story", icon: <Layout size={12} /> },
    { label: "Thread", icon: <Layout size={12} /> }
  ];

  return (
    <>
      {/* MOBILE OVERLAY BACKDROP */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-[145] lg:hidden"
          onClick={() => setIsOpen(false)}
        />
      )}

      <aside 
        className={`fixed inset-y-0 left-0 lg:relative z-[150] h-screen bg-white transition-all duration-300 ease-in-out shrink-0 
          ${isOpen ? 'w-72 translate-x-0' : 'w-24 -translate-x-full lg:translate-x-0'} 
          flex flex-col border-r border-slate-100 lg:border-none`}
      >
        {/* COMBINED TOGGLE GROUP (Laptop Only) */}
        <div 
          className="hidden lg:flex absolute -right-6 top-1/2 -translate-y-1/2 items-center z-[160] cursor-pointer group"
          onClick={() => setIsOpen(!isOpen)}
        >
          {/* Funnel Icon Button - Positioned to the left */}
          <div className="w-10 h-10 bg-blue-600 text-white rounded-full flex items-center justify-center shadow-lg group-hover:bg-blue-700 transition-colors z-10 translate-x-2">
            <Filter size={16} />
          </div>
          
          {/* Arrow Toggle Button - Combined into a larger click area */}
          <div className="w-8 h-14 bg-white border border-slate-200 border-l-0 rounded-r-2xl flex items-center justify-center shadow-sm group-hover:bg-slate-50 pl-2">
            {isOpen ? (
              <ChevronLeft size={16} className="text-slate-400" />
            ) : (
              <ChevronRight size={16} className="text-slate-400" />
            )}
          </div>
        </div>

        {/* MOBILE CLOSE BUTTON */}
        <button 
          onClick={() => setIsOpen(false)}
          className="lg:hidden absolute right-4 top-6 p-2 text-slate-400"
        >
          <X size={20} />
        </button>

        {/* LOGO AREA */}
        <div className="p-4 flex items-center justify-center h-20 shrink-0">
          <img 
            src={LogoWhite} 
            alt="Logo" 
            className={`transition-all duration-300 object-contain ${isOpen ? 'w-32' : 'w-10'}`}
          />
        </div>

        {/* MAIN CONTENT */}
        <div className="flex-1 overflow-hidden py-4 px-4 flex flex-col gap-4">
          
          {/* BRAND FILTER SECTION */}
          <div className={`flex flex-col transition-all duration-300 ${isBrandOpen ? 'flex-1 min-h-0' : 'shrink-0'}`}>
            <div 
              className={`flex items-center gap-3 mb-4 transition-all cursor-pointer ${!isOpen ? 'justify-center h-full' : ''}`}
              onClick={() => isOpen && setIsBrandOpen(!isBrandOpen)}
            >
              {isOpen ? (
                <>
                  <div className="w-12 h-12 rounded-2xl bg-indigo-50 flex items-center justify-center text-indigo-600 font-black shadow-sm shrink-0">B</div>
                  <div className="flex-1 flex justify-between items-center animate-in slide-in-from-left-2">
                    <span className="text-xs font-black text-slate-800 uppercase tracking-widest">Brand</span>
                    {isBrandOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </div>
                </>
              ) : (
                /* VERTICAL TEXT FOR CLOSED STATE */
                <div className="flex flex-col items-center h-full py-4 gap-6">
                  <div className="w-0.5 flex-1 border-l-2 border-dashed border-slate-200"></div>
                  <span className="text-[12px] font-black text-slate-500 uppercase tracking-[0.4em] [writing-mode:vertical-lr] rotate-180 py-0">
                    Filter Brands
                  </span>
                  <div className="w-0.5 flex-1 border-l-2 border-dashed border-slate-500"></div>
                </div>
              )}
            </div>

            {isOpen && isBrandOpen && (
              <div className="flex flex-col flex-1 min-h-0 ml-4 pl-4 border-l-2 border-indigo-50 animate-in fade-in duration-300">
                <div className="relative mb-4 shrink-0">
                  <Search className="absolute left-3 top-2.5 text-gray-400" size={14} />
                  <input 
                    type="text" 
                    placeholder="Search..." 
                    className="w-full pl-9 pr-4 py-2 bg-slate-50 border-none rounded-xl text-xs outline-none"
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
                <div className="overflow-y-auto custom-scrollbar pr-2 space-y-3">
                  {brands.filter(b => b.toLowerCase().includes(searchQuery.toLowerCase())).map((brand) => (
                    <FilterOption key={brand} label={brand} />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* POST TYPE FILTER SECTION */}
          <div className={`flex flex-col transition-all duration-300 ${isTypeOpen ? 'flex-1 min-h-0' : 'shrink-0'}`}>
            <div 
              className={`flex items-center gap-3 mb-4 transition-all cursor-pointer ${!isOpen ? 'justify-center h-full' : ''}`}
              onClick={() => isOpen && setIsTypeOpen(!isTypeOpen)}
            >
              {isOpen ? (
                <>
                  <div className="w-12 h-12 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-600 font-black shadow-sm shrink-0">T</div>
                  <div className="flex-1 flex justify-between items-center animate-in slide-in-from-left-2">
                    <span className="text-xs font-black text-slate-800 uppercase tracking-widest">Post Type</span>
                    {isTypeOpen ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
                  </div>
                </>
              ) : (
                /* VERTICAL TEXT FOR CLOSED STATE */
                <div className="flex flex-col items-center h-full py-4 gap-2">
                  <div className="w-0.5 flex-1 border-l-2 border-dashed border-slate-200"></div>
                  <span className="text-[12px] font-black text-slate-500 uppercase tracking-[0.4em] [writing-mode:vertical-lr] rotate-180 py-0">
                    Post Type
                  </span>
                  <div className="w-0.5 flex-1 border-l-2 border-dashed border-slate-200"></div>
                </div>
              )}
            </div>

            {isOpen && isTypeOpen && (
              <div className="overflow-y-auto custom-scrollbar ml-4 pl-4 border-l-2 border-emerald-50 animate-in fade-in duration-300 flex-1 min-h-0 pr-2 space-y-3">
                {postTypes.map((type) => (
                  <FilterOption 
                    key={type.label} 
                    label={type.label} 
                    icon={type.icon} 
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </aside>
    </>
  );
};

const FilterOption = ({ label, icon }) => (
  <label className="flex items-center gap-3 group cursor-pointer">
    <input 
      type="checkbox" 
      className="h-4 w-4 rounded border-slate-200 text-indigo-600 focus:ring-indigo-500 cursor-pointer shrink-0" 
    />
    <div className="flex items-center gap-2 overflow-hidden">
      {icon && <span className="text-slate-400 group-hover:text-indigo-500 transition-colors shrink-0">{icon}</span>}
      <span className="text-[11px] font-bold text-slate-500 group-hover:text-indigo-600 transition-colors uppercase tracking-tight truncate">
        {label}
      </span>
    </div>
  </label>
);

export default Sidebar;