import React, { useState, useRef, useEffect } from 'react';
import { 
  Plus, ChevronLeft, ChevronRight, Clock, Layout, 
  Calendar as CalendarIcon, List, Eye, ExternalLink, X,
  Video, Image, Mail, Mic, Pencil
} from 'lucide-react';
import FullCalendar from "@fullcalendar/react";
import daygridPlugin from "@fullcalendar/daygrid";
import interactionPlugin from "@fullcalendar/interaction";
import RightSidebar from './RightSidebar'; 

const DailyStackView = ({ isSidebarOpen }) => {
  const [viewMode, setViewMode] = useState('weekly'); 
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedPost, setSelectedPost] = useState(null);
  const [isSidebarDetailOpen, setIsSidebarDetailOpen] = useState(false);
  const calendarRef = useRef(null);

  const currentUser = { name: "Sarah J.", role: "staff" };

  const [posts, setPosts] = useState([
    { 
      id: '1', 
      title: "Apple: Reel",
      post_name: "Nike Jordan air Posting eeeee jkdmdbmshndamnbfsndbmjbsmda",
      brand_name: "Apple", 
      brand_logo: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg",
      post_type: "Reel", 
      status: "Pending", 
      start: "2026-01-09T10:00:00", 
      link: "https://canvas.com/design1",
      view_count: "1.2k",
      created_by: "Sarah J.",
      confirmed_by: "",
      posted_by: "", 
      extendedProps: { status: "Pending", type: "Reel", brand_name: "Apple", created_by: "Sarah J.", confirmed_by: "", posted_by: "", view_count: "1.2k" }
    },
    { 
      id: '2', 
      title: "Google: Canva", 
      post_name: "Winter Collection",
      brand_name: "Google", 
      brand_logo: "https://upload.wikimedia.org/wikipedia/commons/c/c1/Google_\"G\"_logo.svg",
      post_type: "Canva Post", 
      status: "Posted", 
      start: "2026-01-09T14:30:00", 
      link: "https://instagram.com/p/google123",
      view_count: "45.8k",
      created_by: "Mike R.",
      confirmed_by: "Alex P.",
      posted_by: "Alex P.",
      extendedProps: { status: "Posted", type: "Canva Post", brand_name: "Google", created_by: "Mike R.", confirmed_by: "Alex P.", posted_by: "Alex P.", view_count: "45.8k" }
    },
        { 
      id: '1', 
      title: "Apple: Reel",
      post_name: "Nike Jordan air Posting eeeee jkdmdbmshndamnbfsndbmjbsmda",
      brand_name: "Apple", 
      brand_logo: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg",
      post_type: "Reel", 
      status: "Pending", 
      start: "2026-01-09T10:00:00", 
      link: "https://canvas.com/design1",
      view_count: "1.2k",
      created_by: "Sarah J.",
      confirmed_by: "",
      posted_by: "", 
      extendedProps: { status: "Pending", type: "Reel", brand_name: "Apple", created_by: "Sarah J.", confirmed_by: "", posted_by: "", view_count: "1.2k" }
    },
        { 
      id: '1', 
      title: "Apple: Reel",
      post_name: "Nike Jordan air Posting eeeee jkdmdbmshndamnbfsndbmjbsmda",
      brand_name: "Apple", 
      brand_logo: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg",
      post_type: "Reel", 
      status: "Pending", 
      start: "2026-01-09T10:00:00", 
      link: "https://canvas.com/design1",
      view_count: "1.2k",
      created_by: "Sarah J.",
      confirmed_by: "",
      posted_by: "", 
      extendedProps: { status: "Pending", type: "Reel", brand_name: "Apple", created_by: "Sarah J.", confirmed_by: "", posted_by: "", view_count: "1.2k" }
    },
        { 
      id: '1', 
      title: "Apple: Reel",
      post_name: "Nike Jordan air Posting eeeee jkdmdbmshndamnbfsndbmjbsmda",
      brand_name: "Apple", 
      brand_logo: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg",
      post_type: "Reel", 
      status: "Pending", 
      start: "2026-01-010T10:00:00", 
      link: "https://canvas.com/design1",
      view_count: "1.2k",
      created_by: "Sarah J.",
      confirmed_by: "",
      posted_by: "", 
      extendedProps: { status: "Pending", type: "Reel", brand_name: "Apple", created_by: "Sarah J.", confirmed_by: "", posted_by: "", view_count: "1.2k" }
    },
        { 
      id: '1', 
      title: "Apple: Reel",
      post_name: "Nike Jordan air Posting eeeee jkdmdbmshndamnbfsndbmjbsmda",
      brand_name: "Apple", 
      brand_logo: "https://upload.wikimedia.org/wikipedia/commons/f/fa/Apple_logo_black.svg",
      post_type: "Reel", 
      status: "Pending", 
      start: "2026-01-07T10:00:00", 
      link: "https://canvas.com/design1",
      view_count: "1.2k",
      created_by: "Sarah J.",
      confirmed_by: "",
      posted_by: "", 
      extendedProps: { status: "Pending", type: "Reel", brand_name: "Apple", created_by: "Sarah J.", confirmed_by: "", posted_by: "", view_count: "1.2k" }
    }
  ]);

  const getMonday = (d) => {
    const date = new Date(d);
    const day = date.getDay();
    const diff = date.getDate() - day + (day === 0 ? -6 : 1); 
    return new Date(date.setDate(diff));
  };

  const getWeekDates = (startDate) => {
    const monday = getMonday(startDate);
    return Array.from({ length: 7 }, (_, i) => {
      const d = new Date(monday);
      d.setDate(monday.getDate() + i);
      return d;
    });
  };

  useEffect(() => {
    const calendarApi = calendarRef.current?.getApi();
    if (calendarApi && viewMode === 'monthly') {
      calendarApi.changeView('dayGridMonth');
      setTimeout(() => { calendarApi.updateSize(); }, 300);
    }
  }, [viewMode, isSidebarOpen]);

  const handlePostClick = (postData) => {
    setSelectedPost(postData);
    setIsSidebarDetailOpen(true);
  };

  const handleSaveChanges = (updatedPost) => {
    setPosts(prevPosts => prevPosts.map(p => p.id === updatedPost.id ? updatedPost : p));
    setIsSidebarDetailOpen(false);
  };

  const getStatusStyles = (status) => {
    switch (status) {
      case "Pending": return { bg: "bg-purple-50", border: "border-purple-200", accent: "bg-purple-600", text: "text-purple-700" };
      case "Created": return { bg: "bg-blue-50", border: "border-blue-200", accent: "bg-blue-600", text: "text-blue-700" };
      case "Confirmed": return { bg: "bg-amber-50", border: "border-amber-200", accent: "bg-amber-600", text: "text-amber-700" };
      case "Posted": return { bg: "bg-emerald-50", border: "border-emerald-200", accent: "bg-emerald-600", text: "text-emerald-700" };
      default: return { bg: "bg-slate-50", border: "border-slate-200", accent: "bg-slate-600", text: "text-slate-700" };
    }
  };

  const getPostTypeIcon = (type) => {
    const t = type.toLowerCase();
    const iconSize = 18; 
    if (t.includes('reel') || t.includes('video')) return <Video size={iconSize} className="text-slate-600" />;
    if (t.includes('canva') || t.includes('image') || t.includes('post')) return <Image size={iconSize} className="text-slate-600" />;
    if (t.includes('mail')) return <Mail size={iconSize} className="text-slate-600" />;
    if (t.includes('engagement')) return <Mic size={iconSize} className="text-slate-600" />;
    return <Layout size={iconSize} />;
  };

  const changeDate = (offset) => {
    const next = new Date(selectedDate);
    const jump = viewMode === 'weekly' ? 7 * offset : offset;
    next.setDate(selectedDate.getDate() + jump);
    setSelectedDate(next);
    if (calendarRef.current) calendarRef.current.getApi().gotoDate(next);
  };

  const weekDates = getWeekDates(selectedDate);

  const StatusTag = ({ label, color, isActive }) => {
    const variants = {
      green: "bg-emerald-50 border-emerald-500 text-emerald-600",
      orange: "bg-orange-50 border-orange-500 text-orange-600",
      slate: "bg-slate-50 border-slate-300 text-slate-400"
    };
    const style = isActive ? variants[color] : variants.orange;
    return (
      <span className={`px-2 py-1 rounded-md border text-[8px] font-black uppercase tracking-widest whitespace-nowrap ${style}`}>
        {label}
      </span>
    );
  };

  return (
    <div className="flex h-screen overflow-hidden relative bg-slate-50">
      <div className="flex-1 flex flex-col min-w-0">
        
        {/* NAVIGATION HEADER */}
        <div className="px-4 md:px-8 pt-4 md:pt-8 shrink-0 z-[100]">
          <div className="w-full min-h-20 bg-white border border-slate-200 rounded-2xl md:rounded-[32px] shadow-sm flex flex-col md:flex-row items-center justify-between p-4 md:px-8 gap-4">
            <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
              <div className="px-5 py-2.5 bg-slate-100 rounded-xl border border-slate-200 min-w-[140px] text-center">
                <h1 className="text-sm md:text-xl font-black text-slate-800 uppercase tracking-tighter">
                  {viewMode === 'weekly' 
                    ? `${weekDates[0].toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${weekDates[6].toLocaleDateString('en-US', { day: 'numeric' })}`
                    : selectedDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
                  }
                </h1>
              </div>
              <div className="flex items-center bg-slate-100 rounded-xl p-1 border border-slate-200">
                <button onClick={() => changeDate(-1)} className="p-2.5 hover:bg-white rounded-lg text-slate-600 transition-colors"><ChevronLeft size={18}/></button>
                <button onClick={() => setSelectedDate(new Date())} className="px-3 text-[10px] font-black uppercase text-slate-600">Today</button>
                <button onClick={() => changeDate(1)} className="p-2.5 hover:bg-white rounded-lg text-slate-600 transition-colors"><ChevronRight size={18}/></button>
              </div>
            </div>

            <div className="flex bg-slate-100 p-1.5 rounded-xl md:rounded-2xl border border-slate-200 overflow-x-auto max-w-full">
              {[
                { id: 'today', label: 'Day', icon: <List size={14}/> }, 
                { id: 'weekly', label: 'Week', icon: <Layout size={14}/> }, 
                { id: 'monthly', label: 'Month', icon: <CalendarIcon size={14}/> }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setViewMode(tab.id)}
                  className={`flex items-center gap-2 px-4 md:px-6 py-2.5 rounded-lg md:rounded-xl text-[9px] md:text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                    viewMode === tab.id ? 'bg-white text-indigo-600 shadow-sm border border-slate-100' : 'text-slate-500 hover:text-slate-700'
                  }`}
                >
                  {tab.icon} <span className="hidden sm:inline">{tab.label}</span>
                </button>
              ))}
            </div>

            <button className="hidden md:flex items-center gap-2 px-8 py-3.5 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-indigo-600 shadow-lg transition-all">
              <Plus size={16} /> New Post
            </button>
          </div>
        </div>

        {/* CONTENT AREA */}
        <div className="flex-1 p-4 md:px-8 md:pb-8 md:pt-6 overflow-hidden flex flex-col">
          <div className="bg-white rounded-3xl md:rounded-[40px] border border-slate-200 flex flex-col flex-1 overflow-hidden shadow-sm">
            
            {viewMode !== 'monthly' ? (
              <div className="flex-1 overflow-y-auto p-4 md:p-10 custom-scrollbar">
                <div className="space-y-8 w-full max-w-[1600px] mx-auto">
                  {(viewMode === 'today' ? [selectedDate] : weekDates).map((date) => {
                    const dayPosts = posts.filter(p => new Date(p.start).toDateString() === date.toDateString());
                    const isToday = new Date().toDateString() === date.toDateString();
                    
                    return (
                      <div key={date.toISOString()} className="space-y-4">
                        <div className="flex items-center gap-4 px-2">
                          <h3 className={`text-[11px] font-black uppercase tracking-[0.3em] ${isToday ? 'text-indigo-600' : 'text-slate-400'}`}>
                            {date.toLocaleDateString('en-US', { weekday: 'long' })}
                          </h3>
                          <span className="text-[11px] font-bold text-slate-300">
                            {date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                          </span>
                          <div className="flex-1 h-[1px] bg-slate-100"></div>
                        </div>

                        <div className="space-y-3">
                          {dayPosts.length > 0 ? (
                            dayPosts.map((post) => {
                              return (
                                <div 
                                  key={post.id} 
                                  onClick={() => handlePostClick(post)}
                                  className="group cursor-pointer py-5 px-4 md:px-8 rounded-2xl md:rounded-[2rem] border-2 border-slate-100 bg-white hover:border-indigo-200 transition-all duration-300 flex items-center shadow-sm hover:shadow-md"
                                >
                                  {/* LOGO */}
                                  <div className="w-10 h-10 bg-slate-50 rounded-xl flex items-center justify-center border border-slate-100 overflow-hidden shrink-0 mr-4 md:mr-8">
                                    <img src={post.brand_logo} alt={post.brand_name} className="w-6 h-6 object-contain" />
                                  </div>

                                  <div className="flex-1 grid grid-cols-1 md:grid-cols-[1.8fr_1fr_1fr_1fr] gap-4 items-center min-w-0">
                                    
                                    {/* COLUMN 1: Brand:Title + Creator & Ready Status */}
                                    <div className="flex flex-col gap-1.5 pr-2 min-w-0">
                                      <div className="text-[14px] md:text-[15px] font-black text-slate-900 uppercase tracking-tight truncate max-w-full md:max-w-[400px]">
                                        {post.brand_name}: <span className="text-slate-500 font-bold">{post.post_name}</span>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <div className="flex items-center gap-1.5 text-slate-700">
                                          <Pencil size={11} className="text-slate-400" />
                                          <span className="text-[11px] md:text-[13px] font-black tracking-wide truncate">{post.created_by || "System"}</span>
                                        </div>
                                        <StatusTag 
                                          label={post.status === 'Pending' ? 'Not Ready' : 'Ready'} 
                                          color={post.status === 'Pending' ? 'orange' : 'green'} 
                                          isActive={true} 
                                        />
                                      </div>
                                    </div>

                                    {/* COLUMN 2: Post Type (Smaller Font) */}
                                    <div className="flex items-center gap-3 px-0 md:px-6 md:border-l border-slate-100">
                                      <div className="p-2 bg-slate-50 rounded-lg shrink-0">{getPostTypeIcon(post.post_type)}</div>
                                      <span className="text-[10px] md:text-[11px] font-black uppercase text-slate-500 tracking-widest whitespace-nowrap">{post.post_type}</span>
                                    </div>

                                    {/* COLUMN 3: Confirmed Tag */}
                                    <div className="flex justify-start md:justify-center md:border-l border-slate-100">
                                      <StatusTag 
                                        label={post.confirmed_by ? "Confirmed" : "Not Confirmed"} 
                                        color="green" 
                                        isActive={!!post.confirmed_by} 
                                      />
                                    </div>

                                    {/* COLUMN 4: Posted Tag */}
                                    <div className="flex justify-start md:justify-center md:border-l border-slate-100">
                                      <StatusTag 
                                        label={post.status === "Posted" ? "Posted" : "Not Posted"} 
                                        color="green" 
                                        isActive={post.status === "Posted"} 
                                      />
                                    </div>

                                  </div>

                                  {/* TIME DISPLAY */}
                                  <div className="ml-4 md:ml-10 flex items-center gap-2 text-slate-400 font-bold text-[11px] shrink-0">
                                    <Clock size={12}/>
                                    <span className="hidden sm:inline">{new Date(post.start).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                                  </div>
                                </div>
                              );
                            })
                          ) : (
                            <div className="h-1 opacity-0"></div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="flex-1 calendar-container overflow-hidden bg-white p-0 rounded-3xl md:rounded-[40px]">
                <style>{`
                  .fc { font-family: inherit; border: none; height: 100% !important; background-color: white !important; border-radius: inherit !important; overflow: hidden !important; }
                  .fc-theme-standard td, .fc-theme-standard th { border: 1px solid #f1f5f9 !important; }
                  .fc-header-toolbar { display: none !important; }
                  .fc-col-header-cell { background: white; padding: 15px 0 !important; border-bottom: 1px solid #f1f5f9 !important; }
                  .fc-col-header-cell-cushion { font-size: 11px; font-weight: 900; text-transform: uppercase; color: #94a3b8; letter-spacing: 0.1em; }
                  .fc-daygrid-day-number { font-size: 13px; font-weight: 900; color: #1e293b; padding: 12px !important; }
                  .fc-event { border: none !important; background: transparent !important; margin: 3px 6px !important; }
                `}</style>
                <FullCalendar
                  ref={calendarRef}
                  plugins={[daygridPlugin, interactionPlugin]}
                  initialView="dayGridMonth"
                  events={posts}
                  height="100%"
                  dayMaxEvents={3}
                  headerToolbar={false}
                  eventContent={(info) => <CalendarEvent info={info} getStatusStyles={getStatusStyles} />}
                  eventClick={(info) => handlePostClick(info.event.extendedProps)}
                />
              </div>
            )}
          </div>
        </div>
      </div>

      <RightSidebar 
        isOpen={isSidebarDetailOpen} 
        onClose={() => setIsSidebarDetailOpen(false)} 
        post={selectedPost}
        currentUser={currentUser}
        onSave={handleSaveChanges} 
      />
    </div>
  );
};

const CalendarEvent = ({ info, getStatusStyles }) => {
  const p = info.event.extendedProps;
  const styles = getStatusStyles(p.status);
  return (
    <div className={`p-1.5 rounded-lg border-l-[4px] shadow-sm ${styles.bg} ${styles.border} ${styles.text} truncate transition-transform hover:scale-[1.02]`}>
      <div className="text-[9px] font-black uppercase leading-tight">{p.brand_name}</div>
    </div>
  );
};

export default DailyStackView;