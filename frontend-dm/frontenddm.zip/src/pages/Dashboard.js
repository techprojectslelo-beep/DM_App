import React, { useState } from 'react';
import Sidebar from '../components/layout/Sidebar';
import Header from '../components/layout/header';
import DailyStackView from '../components/views/DailyStackView';
import BrandsList from '../pages/BrandList'; 
import BrandDetail from '../pages/BrandDetail';
import UsersList from '../pages/UsersList'; 
import UserDetail from '../pages/UserDetail';

const Dashboard = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // Navigation State
  const [activeView, setActiveView] = useState('dashboard'); 
  const [selectedBrandId, setSelectedBrandId] = useState(null);
  const [selectedUserId, setSelectedUserId] = useState(null); 

  const handleViewChange = (view) => {
    setActiveView(view);
    setSelectedBrandId(null); 
    setSelectedUserId(null);
  };

  return (
    <div className="flex h-screen bg-white font-sans overflow-hidden">
      <Sidebar isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />
      
      <div className="flex-1 flex flex-col relative overflow-hidden">
        {/* ADDED setIsSidebarOpen PROP HERE */}
        <Header 
          activePage={activeView} 
          setActivePage={handleViewChange} 
          setIsSidebarOpen={setIsSidebarOpen} 
        />

        <main className="flex-1 bg-white relative min-h-0">
          {/* Main Gray Container - Adjusted rounding for mobile consistency */}
          <div className="w-full h-full bg-[#f1f5f9] rounded-tl-[24px] lg:rounded-tl-[70px] flex flex-col shadow-[inset_4px_4px_15px_rgba(0,0,0,0.02)] overflow-hidden">
            
            {/* WRAPPER: Removed overflow-y-auto so this container doesn't scroll */}
            <div className="flex-1 overflow-hidden flex flex-col">
              
              {/* Case 1: Dashboard */}
              {activeView === 'dashboard' && (
                <DailyStackView isSidebarOpen={isSidebarOpen} />
              )}

              {/* Case 2: Brands Tab */}
              {activeView === 'brands' && (
                <div className="flex-1 overflow-y-auto pt-8 px-4 md:px-8">
                  {selectedBrandId ? (
                    <BrandDetail 
                      brandId={selectedBrandId} 
                      onBack={() => setSelectedBrandId(null)} 
                    />
                  ) : (
                    <BrandsList 
                      onBrandClick={(id) => setSelectedBrandId(id)} 
                    />
                  )}
                </div>
              )}

              {/* Case 3: Users Tab */}
              {activeView === 'users' && (
                <div className="flex-1 overflow-y-auto pt-8 px-4 md:px-8">
                  {selectedUserId ? (
                    <UserDetail 
                      userId={selectedUserId} 
                      onBack={() => setSelectedUserId(null)} 
                    />
                  ) : (
                    <UsersList 
                      onUserClick={(id) => setSelectedUserId(id)} 
                    />
                  )}
                </div>
              )}
              
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default Dashboard;