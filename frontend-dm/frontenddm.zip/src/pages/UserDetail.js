import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import { 
  ArrowLeft, User, Mail, ShieldCheck, 
  Lock, Unlock, Save, X, Trash2, Clock, 
  Activity, Calendar
} from "lucide-react";
import Button from "../components/ui/button/Button";

export default function UserDetail({ userId, onBack }) {
  const [isEditing, setIsEditing] = useState(false);
  
  const [profile, setProfile] = useState({
    name: "Sarah Jenkins",
    role: "Admin",
    email: "sarah.j@agency.com",
    joinedDate: "2025-05-12",
    status: "Active"
  });

  // Mock Activity Log
  const [logs] = useState([
    { id: 'l1', action: 'Created Post', target: 'Apple: Reel', timestamp: '2026-01-09 10:00' },
    { id: 'l2', action: 'Confirmed Post', target: 'Nike: Image', timestamp: '2026-01-08 14:30' },
    { id: 'l3', action: 'Updated Brand', target: 'Coca Cola', timestamp: '2026-01-07 09:15' },
  ]);

  const roles = ["Admin", "Manager", "Creator", "Staff"];

  const handleDeleteUser = () => {
    if(window.confirm("FATAL ACTION: Are you sure you want to delete this user? This cannot be undone.")) {
        // Logic to delete user
        onBack();
    }
  };

  return (
    <div className="p-4 md:p-6 space-y-6 max-w-7xl mx-auto">
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <button onClick={onBack} className="group flex items-center gap-2 text-gray-400 hover:text-indigo-600 transition-colors font-black uppercase text-[10px] tracking-widest">
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" /> Return to directory
        </button>

        <div className="flex gap-2">
            <Button onClick={handleDeleteUser} variant="ghost" className="text-red-500 hover:bg-red-50 rounded-2xl border border-red-100">
                <Trash2 size={16} className="mr-2" /> Delete User
            </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        
        {/* LEFT COLUMN: USER PROFILE */}
        <div className="lg:col-span-4 space-y-6 lg:sticky lg:top-6">
          <div className="bg-white border border-gray-100 rounded-[35px] p-6 shadow-sm space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-[10px] font-black uppercase text-gray-400 tracking-widest">System Identity</h3>
              <button onClick={() => setIsEditing(!isEditing)} className="transition-transform active:scale-90">
                {isEditing ? <Unlock size={16} className="text-green-500 animate-pulse" /> : <Lock size={16} className="text-gray-300" />}
              </button>
            </div>

            <div className="flex flex-col items-center py-4">
                <div className="w-24 h-24 bg-indigo-600 rounded-[2rem] flex items-center justify-center text-white mb-4 shadow-xl shadow-indigo-200">
                    <User size={40} />
                </div>
                <h2 className="text-xl font-black uppercase tracking-tight text-gray-900">{profile.name}</h2>
                <span className="text-[10px] font-black uppercase text-indigo-500 bg-indigo-50 px-3 py-1 rounded-full mt-2 tracking-widest">
                    {profile.role}
                </span>
            </div>

            <div className="space-y-4">
              <DetailInput label="Full Name" icon={User} value={profile.name} disabled={!isEditing} onChange={(v) => setProfile({...profile, name: v})} />
              <DropdownInput label="System Role" icon={ShieldCheck} value={profile.role} options={roles} disabled={!isEditing} onChange={(v) => setProfile({...profile, role: v})} />
              <DetailInput label="Email Address" icon={Mail} value={profile.email} disabled={!isEditing} onChange={(v) => setProfile({...profile, email: v})} />
            </div>

            {isEditing && (
              <Button onClick={() => setIsEditing(false)} className="w-full py-4 rounded-2xl animate-in fade-in slide-in-from-bottom-2 bg-indigo-600 shadow-lg shadow-indigo-100">
                <Save size={16} className="mr-2" /> Save Profile
              </Button>
            )}
          </div>

          <div className="p-5 bg-slate-900 rounded-[2.5rem] text-white">
             <div className="flex items-center gap-3 mb-2">
                <Calendar size={16} className="text-indigo-400" />
                <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Member Since</p>
             </div>
             <p className="text-lg font-black">{new Date(profile.joinedDate).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
          </div>
        </div>

        {/* RIGHT COLUMN: ACTIVITY LOGS */}
        <div className="lg:col-span-8">
            <div className="space-y-6">
              <div className="flex items-center gap-4 px-2">
                 <h3 className="text-xs font-black uppercase tracking-[0.4em] text-gray-400">Activity History</h3>
                 <div className="flex-1 h-[1px] bg-gray-100"></div>
              </div>

              <div className="rounded-[35px] border border-gray-100 bg-white overflow-hidden shadow-sm">
                <Table className="w-full text-left">
                  <TableHeader className="bg-gray-50/50">
                    <TableRow>
                      <TableCell isHeader className="px-6 py-5">Action Performed</TableCell>
                      <TableCell isHeader className="px-6 py-5">Timestamp</TableCell>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {logs.map((log) => (
                      <TableRow key={log.id} className="group border-b border-gray-50 last:border-none">
                        <TableCell className="px-6 py-6">
                          <div className="flex items-center gap-3">
                            <div className="p-2 bg-slate-50 rounded-lg text-slate-400 group-hover:text-indigo-500 transition-colors">
                                <Activity size={14} />
                            </div>
                            <div>
                                <div className="font-bold text-gray-900 uppercase text-xs mb-0.5">{log.action}</div>
                                <div className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Target: {log.target}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="px-6 py-6">
                           <div className="flex items-center gap-2 text-[11px] font-bold text-gray-500 uppercase">
                              <Clock size={12} /> {log.timestamp}
                           </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
        </div>
      </div>
    </div>
  );
}

// SHARED HELPER COMPONENTS
function DetailInput({ label, icon: Icon, ...props }) {
  return (
    <div className="text-left w-full">
      <label className="text-[9px] font-black uppercase text-gray-400 block mb-1.5 ml-1 tracking-widest">{label}</label>
      <div className="relative">
        <Icon size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-500" />
        <input {...props} className="w-full rounded-2xl pl-11 pr-4 py-3 text-xs font-bold transition-all outline-none border border-indigo-100 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-50 disabled:bg-gray-50 disabled:border-transparent disabled:text-gray-400" />
      </div>
    </div>
  );
}

function DropdownInput({ label, icon: Icon, options, value, onChange, disabled }) {
  return (
    <div className="text-left w-full">
      <label className="text-[9px] font-black uppercase text-gray-400 block mb-1.5 ml-1 tracking-widest">{label}</label>
      <div className="relative">
        <Icon size={14} className="absolute left-4 top-1/2 -translate-y-1/2 text-indigo-500 z-10" />
        <select 
            disabled={disabled}
            value={value} 
            onChange={(e) => onChange?.(e.target.value)} 
            className="w-full rounded-2xl pl-11 pr-4 py-3 text-xs font-bold appearance-none outline-none border border-indigo-100 focus:border-indigo-500 bg-white disabled:bg-gray-50 disabled:text-gray-400"
        >
            {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
      </div>
    </div>
  );
}